<footer class="footer" id="footer">
    <div class="container">
        <div class="row">
            <div class="col-12 d-flex justify-content-between align-items-center"><a class="logo" href=""><img src="<?php echo e(asset('/static/img/logo.png')); ?>" alt=""></a>
                <nav class="menu d-none d-lg-flex">
                    <ul>
                        <li><a class="scroll-link" href="#benefits">Преимущества</a></li>
                        <li><a class="scroll-link" href="#map">География</a></li>
                        <li><a class="scroll-link" href="#timeline">Этапы работ</a></li>
                        <li><a class="scroll-link" href="blog-page.blade.php">Статьи</a></li>
                    </ul>
                </nav>
                <div class="phone"><img src="<?php echo e(asset('/static/img/phone-icon.png')); ?>" alt="">+ 7 923 32-423-42</div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <nav class="menu d-lg-none">
                    <ul>
                        <li><a class="scroll-link" href="#benefits">Преимущества</a></li>
                        <li><a class="scroll-link" href="#map">География</a></li>
                        <li><a class="scroll-link" href="#timeline">Этапы работ</a></li>
                        <li><a class="scroll-link" href="blog-page.blade.php">Статьи</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</footer><?php /**PATH C:\OSPanel\domains\lara\resources\views/assets/footer.blade.php ENDPATH**/ ?>