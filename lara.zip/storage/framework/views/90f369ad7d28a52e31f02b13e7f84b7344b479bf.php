Имя: <strong><?php echo e($name); ?></strong> <br>
<p>Телефон: <?php echo e($body); ?></p>

<p>Откуда:<?php echo e($selectFrom); ?></p>

<p>Куда: <?php echo e($selectTo); ?></p>

<p>Вес, кг:<?php echo e($weight); ?></p>

<p>Наименование груза: <?php echo e($title); ?></p>

<p>Тип подвижного состава: <?php echo e($type_of_train); ?></p>

<p>Ip Клиента: <?php echo e($ip); ?></p><?php /**PATH C:\OSPanel\domains\lara\resources\views/mail/sendmessage.blade.php ENDPATH**/ ?>