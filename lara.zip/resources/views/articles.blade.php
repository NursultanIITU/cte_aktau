<div class="articles">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h2>На все вагоны мы предоставляем пломбы (ЗПУ),<span>которые гарантируют сохранность грузов</span></h2>
            </div>
        </div>
        <div class="row">
            <div class="col-12 d-sm-flex justify-content-center">
                <div class="article">
                    <div class="article__img"><img src="{{asset('/static/img/article-img.jpg')}}" alt=""></div>
                    <div class="article__title">Пломба ЗПУ - модель</div>
                    <div class="article__text">Задача организации, в особенности же реализация намеченных плановых заданий позволяет выполнять важные задания по разработке дальнейших направлений.</div><a class="btn btn--blue btn--md" href=""><span>Подробнее</span></a>
                </div>
                <div class="article">
                    <div class="article__img"><img src="{{asset('/static/img/article-img.jpg')}}" alt=""></div>
                    <div class="article__title">Пломба ЗПУ - модель</div>
                    <div class="article__text">Задача организации, в особенности же реализация намеченных плановых заданий позволяет выполнять важные задания по разработке дальнейших направлений.</div><a class="btn btn--blue btn--md" href=""><span>Подробнее</span></a>
                </div>
            </div>
        </div>
    </div>
</div>