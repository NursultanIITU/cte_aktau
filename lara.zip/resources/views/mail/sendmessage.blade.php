Имя: <strong>{{ $name }}</strong> <br>
<p>Телефон: {{ $body }}</p>

<p>Откуда:{{$selectFrom}}</p>

<p>Куда: {{$selectTo}}</p>

<p>Вес, кг:{{$weight}}</p>

<p>Наименование груза: {{$title}}</p>

<p>Тип подвижного состава: {{$type_of_train}}</p>

<p>Ip Клиента: {{$ip}}</p>