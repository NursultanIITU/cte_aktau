@extends('layouts.app')

@section('content')
      @include('hero')

      @include('steps')

      @include('benefits')

      @include('map')

      @include('timeline')

      @include('articles')
@endsection


  
